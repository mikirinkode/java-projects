/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import utp.game.Character;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Lenovo
 */
public class CharacterTest {
    
    public CharacterTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of getName method, of class Character.
     */
    @Test
    public void testGetName() {
        System.out.println("getName");
        Character instance = new Character();
        String expResult = "";
        String result = instance.getName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setName method, of class Character.
     */
    @Test
    public void testSetName() {
        System.out.println("setName");
        String name = "";
        Character instance = new Character();
        instance.setName(name);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getHealth method, of class Character.
     */
    @Test
    public void testGetHealth() {
        System.out.println("getHealth");
        Character instance = new Character();
        int expResult = 0;
        int result = instance.getHealth();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setHealth method, of class Character.
     */
    @Test
    public void testSetHealth() {
        System.out.println("setHealth");
        int health = 0;
        Character instance = new Character();
        instance.setHealth(health);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getAttackPower method, of class Character.
     */
    @Test
    public void testGetAttackPower() {
        System.out.println("getAttackPower");
        Character instance = new Character();
        int expResult = 0;
        int result = instance.getAttackPower();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setAttackPower method, of class Character.
     */
    @Test
    public void testSetAttackPower() {
        System.out.println("setAttackPower");
        int attackPower = 0;
        Character instance = new Character();
        instance.setAttackPower(attackPower);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of attack method, of class Character.
     */
    @Test
    public void testAttack() {
        System.out.println("attack");
        Character character = null;
        Character instance = new Character();
        String expResult = "";
        String result = instance.attack(character);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of defend method, of class Character.
     */
    @Test
    public void testDefend() {
        System.out.println("defend");
        Character instance = new Character();
        String expResult = "";
        String result = instance.defend();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of printAttributes method, of class Character.
     */
    @Test
    public void testPrintAttributes() {
        System.out.println("printAttributes");
        Character instance = new Character();
        instance.printAttributes();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of cetakAttributes method, of class Character.
     */
    @Test
    public void testCetakAttributes() {
        System.out.println("cetakAttributes");
        Character instance = new Character();
        String expResult = "";
        String result = instance.cetakAttributes();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
